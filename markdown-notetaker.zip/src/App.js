import "./App.css";
import Notebook from "./components/Notebook";

function App() {
  return (
    <div className="App">
      <Notebook />
    </div>
  );
}

export default App;
